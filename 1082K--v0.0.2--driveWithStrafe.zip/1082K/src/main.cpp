// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LF                   motor         1               
// RF                   motor         2               
// LB                   motor         3               
// RB                   motor         4               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

void pre_auton(void) {
  vexcodeInit();
  LF.setStopping(coast);
  LB.setStopping(coast);
  RF.setStopping(coast);
  RB.setStopping(coast);
}

void autonomous(void) {
  
}

void usercontrol(void) {
  int fwdPct = 0;
  int sidePct = 0;
  int strafePct = 0;

  while (1) {
    fwdPct = Controller1.Axis3.position(pct);
    sidePct = Controller1.Axis1.position(pct);
    strafePct = Controller1.Axis4.position(pct);

    LF.spin(forward, fwdPct + sidePct + strafePct, percent);
    RF.spin(forward, fwdPct - sidePct - strafePct, percent);
    LB.spin(forward, fwdPct + sidePct - strafePct, percent);
    RB.spin(forward, fwdPct - sidePct + strafePct, percent);
    wait(20, msec);
  }
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  pre_auton();

  while (true) {
    wait(100, msec);
  }
}
