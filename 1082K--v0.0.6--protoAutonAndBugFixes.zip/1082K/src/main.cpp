// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LF                   motor         1               
// RF                   motor         2               
// LB                   motor         3               
// RB                   motor         4               
// Intake               motor         6               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

int autonToRun = -1;

class Button
{
  public:
    int x, y, width, height;
    std::string text;
    vex::color buttonColor, textColor;
    
    Button(int x, int y, int width, int height, std::string text, vex::color buttonColor, vex::color textColor)
    : x(x), y(y), width(width), height(height), text(text), buttonColor(buttonColor), textColor(textColor){}

    void render()
    {
      Brain.Screen.drawRectangle(x, y, width, height, buttonColor);
      Brain.Screen.printAt(x + 10, y + 20, false, text.c_str());
    }

    bool isClicked()
    {
      if(Brain.Screen.pressing() && Brain.Screen.xPosition() >= x && Brain.Screen.xPosition() <= x + width &&
      Brain.Screen.yPosition() >= y && Brain.Screen.yPosition() <= y + width) return true;
      return false;
    }
};

Button autonButtons[] = {
  Button(10, 10, 150, 50, "Auton Left", vex::green, vex::black),
  Button(170, 10, 150, 50, "Auton Right", vex::white, vex::black),
};

void pre_auton(void) {
  vexcodeInit();
}

// Begin Methods for use in Auton

void driveForward(double secs) {
  LF.spin(forward);
  RF.spin(forward);
  LB.spin(forward);
  RB.spin(forward);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveForward(int pwr, double secs) {
  LF.spin(forward, pwr, pct);
  RF.spin(forward, pwr, pct);
  LB.spin(forward, pwr, pct);
  RB.spin(forward, pwr, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveBackward(double secs) {
  LF.spin(reverse);
  RF.spin(reverse);
  LB.spin(reverse);
  RB.spin(reverse);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveBackward(int pwr, double secs) {
  LF.spin(reverse, pwr, pct);
  RF.spin(reverse, pwr, pct);
  LB.spin(reverse, pwr, pct);
  RB.spin(reverse, pwr, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void turnLeft(double secs) {
  LF.spin(reverse);
  RF.spin(forward);
  LB.spin(reverse);
  RB.spin(forward);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void turnRight(double secs) {
  LF.spin(forward);
  RF.spin(reverse);
  LB.spin(forward);
  RB.spin(reverse);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void intakeIn() {
  Intake.spin(forward);
  wait(20, msec);
}

void intakeOut() {
  Intake.spin(reverse);
  wait(20, msec);
}

void intakeOff() {
  Intake.stop();
  wait(20, msec);
}

void autonomous(void) {
  do wait(10, msec); while(autonToRun < 0); {
    if(autonToRun == 0) {
      intakeIn();
      wait(500, msec);
      intakeOff();
      driveBackward(0.5);
      turnLeft(1);
      intakeIn();
      driveForward(1);
      intakeOff();
      turnRight(0.25);
      driveForward(1);
      turnRight(2);
      intakeIn();
    } else if(autonToRun == 1) {
      
    }
  } 
}

void usercontrol(void) {
  int fwdPct = 0;
  int sidePct = 0;
  int strafePct = 0;

  while (1) {
    if(Controller1.Axis3.position(pct) > 5 || Controller1.Axis3.position(pct) < - 5) {
      fwdPct = Controller1.Axis3.position(pct);
    } else {
      fwdPct = 0;
    }
    if(Controller1.Axis1.position(pct) > 5 || Controller1.Axis1.position(pct) < - 5) {
      sidePct = Controller1.Axis1.position(pct);
    } else {
      sidePct = 0;
    }
    if(Controller1.Axis4.position(pct) > 5 || Controller1.Axis4.position(pct) < - 5) {
      strafePct = Controller1.Axis4.position(pct);
    } else {
      strafePct = 0;
    }

    LF.spin(forward, fwdPct + sidePct + strafePct, percent);
    RF.spin(forward, fwdPct - sidePct - strafePct, percent);
    LB.spin(forward, fwdPct + sidePct - strafePct, percent);
    RB.spin(forward, fwdPct - sidePct + strafePct, percent);
    if(Controller1.ButtonUp.pressing()) {
      Intake.spin(forward, 75, pct);
    } else if(Controller1.ButtonDown.pressing()) {
      Intake.spin(reverse, 75, pct);
    } else if(Controller1.ButtonRight.pressing()) {
      Intake.stop();
    }

    wait(20, msec);
  }
}

int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  pre_auton();

  while (true) {
    if(!Competition.isEnabled()) {
      for(int i = 0; i < 2; i++) {
        autonButtons[i].render();
        if(autonButtons[i].isClicked()) {
          autonButtons[autonToRun].buttonColor = vex::black;
          autonButtons[i].buttonColor = vex::green;
          autonToRun = i;
        }
      }
    }
    wait(100, msec);
  }
}
