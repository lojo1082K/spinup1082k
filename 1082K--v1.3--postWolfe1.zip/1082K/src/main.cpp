// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// LF                   motor         1               
// RF                   motor         2               
// LB                   motor         3               
// RB                   motor         4               
// Intake               motor         6               
// RollerMech           motor         7               
// Flywheel             motor_group   8, 9            
// Indexer              digital_out   A               
// Endgame              digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;

int autonToRun = -1;

class Button
{
  public:
    int x, y, width, height;
    std::string text;
    vex::color buttonColor, textColor;
    
    Button(int x, int y, int width, int height, std::string text, vex::color buttonColor, vex::color textColor)
    : x(x), y(y), width(width), height(height), text(text), buttonColor(buttonColor), textColor(textColor){}

    void render()
    {
      Brain.Screen.drawRectangle(x, y, width, height, buttonColor);
      Brain.Screen.printAt(x + 10, y + 20, false, text.c_str());
    }

    bool isClicked()
    {
      if(Brain.Screen.pressing() && Brain.Screen.xPosition() >= x && Brain.Screen.xPosition() <= x + width &&
      Brain.Screen.yPosition() >= y && Brain.Screen.yPosition() <= y + width) return true;
      return false;
    }
};

Button autonButtons[] = {
  Button(10, 30, 150, 50, "Auton Left", vex::green, vex::black),
  Button(170, 30, 150, 50, "Auton Right", vex::white, vex::black),
  Button(170, 90, 150, 50, "PROG SKILLS", vex::white, vex::black),
};

void pre_auton(void) {
  vexcodeInit();
}

// Begin Methods for use in Auton

void driveForward(double secs) {
  LF.spin(forward, 100, pct);
  RF.spin(forward, 100, pct);
  LB.spin(forward, 100, pct);
  RB.spin(forward, 100, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveForward(int pwr, double secs) {
  LF.spin(forward, pwr, pct);
  RF.spin(forward, pwr, pct);
  LB.spin(forward, pwr, pct);
  RB.spin(forward, pwr, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveBackward(double secs) {
  LF.spin(reverse, 100, pct);
  RF.spin(reverse, 100, pct);
  LB.spin(reverse, 100, pct);
  RB.spin(reverse, 100, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void driveBackward(int pwr, double secs) {
  LF.spin(reverse, pwr, pct);
  RF.spin(reverse, pwr, pct);
  LB.spin(reverse, pwr, pct);
  RB.spin(reverse, pwr, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void turnLeft(double secs) {
  LF.spin(reverse, 75, pct);
  RF.spin(forward, 75, pct);
  LB.spin(reverse, 75, pct);
  RB.spin(forward, 75, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void turnRight(double secs) {
  LF.spin(forward, 75, pct);
  RF.spin(reverse, 75, pct);
  LB.spin(forward, 75, pct);
  RB.spin(reverse, 75, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void strafeRight(double secs) {
  LF.spin(forward, 100, pct);
  RF.spin(reverse, 100, pct);
  LB.spin(reverse, 100, pct);
  RB.spin(forward, 100, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void strafeLeft(double secs) {
  LF.spin(reverse, 100, pct);
  RF.spin(forward, 100, pct);
  LB.spin(forward, 100, pct);
  RB.spin(reverse, 100, pct);
  wait(secs, sec);
  LF.stop();
  RF.stop();
  LB.stop();
  RB.stop();
}

void intakeIn() {
  Intake.spin(forward, 100, pct);
  wait(20, msec);
}

void intakeOut() {
  Intake.spin(reverse, 100, pct);
  wait(20, msec);
}

void intakeOff() {
  Intake.stop();
  wait(20, msec);
}

void roller(int x) {
  if(x == 0) {
    RollerMech.spin(forward, 100, pct);
  } else {
    RollerMech.spin(reverse, 100, pct);
  }
  wait(20, msec);
}

void rollerStop() {
  RollerMech.stop();
  wait(20, msec);
}

void startFlywheel() {
  Flywheel.spin(forward, 100, pct);
  wait(20, msec);
}

void startFlywheel(int pwr) {
  Flywheel.spin(forward, pwr, pct);
  wait(20, msec);
}

void stopFlywheel() {
  Flywheel.stop();
  wait(20, msec);
}
void goIndexer() {
  Indexer.set(true);
  wait(20, msec);
  Indexer.set(false);
}

void fireEndGame() {
  Endgame.set(true);
  wait(20, msec);
}

void waitClearScreen() {
  while(1) {
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print(Intake.velocity(percent));
    wait(.1, sec);
    Brain.Screen.clearScreen();
  }
}
// --------------------------------------------------------------------------------------------------- AUTON
void autonomous(void) {
  do wait(10, msec); while(autonToRun < 0); {
    if(autonToRun == 0) {
      // Left Side Auton
      driveForward(0.2);
      roller(1);
      wait(250, msec);
      rollerStop();
      driveBackward(0.1);
      turnLeft(0.09);
      startFlywheel(91);
      wait(3, sec);
      goIndexer();
      wait(2, sec);
      goIndexer();
      wait(100, msec);
      wait(1, sec);
      stopFlywheel();
    } else if(autonToRun == 1) {
      // Right Side Auton
      strafeLeft(0.59);
      wait(50, msec);
      driveForward(0.33);
      roller(1);
      wait(150, msec);
      rollerStop();
      driveBackward(0.2);
      wait(100, msec);
      turnRight(0.100);
      startFlywheel(90);
      wait(4, sec);
      goIndexer();
      wait(4, sec);
      goIndexer();
      wait(100, msec);
      wait(1, sec);
      stopFlywheel();
    } else if(autonToRun == 2) {
      // PROG SKILLS
      driveForward(0.2);
      roller(1);
      wait(175, msec);
      rollerStop();
      driveBackward(0.17);
      wait(500, msec);
      turnLeft(0.47);
      wait(500, msec);
      driveForward(1);
      wait(500, msec);
      turnRight(0.92);
      wait(100, msec);
      startFlywheel(75);
      wait(4, sec);
      goIndexer();
      wait(3, sec);
      goIndexer();
      stopFlywheel();
      wait(1, sec);
      strafeRight(0.25);
      wait(500, msec);
      intakeIn();
      driveForward(1.45);
      wait(500, msec);
      turnRight(0.08);
      wait(500, msec);
      driveForward(0.25);
      roller(1);
      wait(175, msec);
      rollerStop();
      driveBackward(0.3);
      wait(500, msec);
      turnRight(0.7);
      wait(1, sec);
      fireEndGame();
    }
  } 
}
// --------------------------------------------------------------------------------------------------- AUTON
void driverFlywheelCheck() {
  int speed = 0;
  while(1) {
    if(Controller1.ButtonX.pressing()) {
      if(speed != 75) {
        Flywheel.spin(forward, 75, pct);
        speed = 75;
        wait(500, msec);
      } else {
        Flywheel.stop();
        speed = 0;
        wait(500, msec);
      }
    } else if(Controller1.ButtonY.pressing()) {
      if(speed != 100) {
        Flywheel.spin(forward, 100, pct);
        speed = 100;
        wait(500, msec);
      } else {
        Flywheel.stop();
        speed = 0;
        wait(500, msec);
      }
    }
  }
}
void driverIndexerCheck() {
  while(1) {
    if(Controller1.ButtonA.pressing()) {
      Indexer.set(true);
      wait(20, msec);
      Indexer.set(false);
      wait(250, msec);
    } else if(Controller1.ButtonB.pressing()) {
      Indexer.set(true);
      wait(20, msec);
      Indexer.set(false);
      wait(200, msec);
      Indexer.set(true);
      wait(20, msec);
      Indexer.set(false);
      wait(200, msec);
      Indexer.set(true);
      wait(20, msec);
      Indexer.set(false);
      wait(250, msec);
    }
  }
}

void endGameCheck() {
  while(1) {
    if(Controller1.ButtonL1.pressing() && Controller1.ButtonL2.pressing()) {
      Endgame.set(true);
    }
    wait(20, msec);
  }
}
// --------------------------------------------------------------------------------------------------- DRIVER
void usercontrol(void) {
  int fwdPct = 0;
  int sidePct = 0;
  int strafePct = 0;

  vex::thread endgameWait = vex::thread(endGameCheck);
  vex::thread flywheelCheck = vex::thread(driverFlywheelCheck);
  vex::thread indexerCheck = vex::thread(driverIndexerCheck);
  while (1) {
    
     vex::thread clearL = vex::thread(waitClearScreen);
    if(abs(Controller1.Axis3.position(pct)) > 5) {
      fwdPct = Controller1.Axis3.position(pct);
    } else {
      fwdPct = 0;
    }
    if(abs(Controller1.Axis1.position(pct)) > 5) {
      sidePct = Controller1.Axis1.position(pct);
    } else {
      sidePct = 0;
    }
    if(abs(Controller1.Axis4.position(pct)) > 5) {
      strafePct = Controller1.Axis4.position(pct);
    } else {
      strafePct = 0;
    }

    LF.spin(forward, fwdPct + (sidePct * 0.75) + strafePct, percent);
    RF.spin(forward, fwdPct - (sidePct * 0.75) - strafePct, percent);
    LB.spin(forward, fwdPct + (sidePct * 0.75) - strafePct, percent);
    RB.spin(forward, fwdPct - (sidePct * 0.75) + strafePct, percent);
    if(Controller1.ButtonUp.pressing()) {
      Intake.spin(forward, 200, rpm);
    } else if(Controller1.ButtonDown.pressing()) {
      Intake.spin(reverse, 100, pct);
    } else if(Controller1.ButtonRight.pressing()) {
      Intake.stop();
    }
    if(Controller1.ButtonR1.pressing()) {
      RollerMech.spin(forward);
    } else if(Controller1.ButtonR2.pressing()) {
      RollerMech.spin(reverse);
    } else {
      RollerMech.stop();
    }
    
    wait(20, msec);
  }
}
// --------------------------------------------------------------------------------------------------- DRIVER
int main() {
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  pre_auton();

  while (true) {
    for(int i = 0; i < 3; i++) {
      autonButtons[i].render();
      if(autonButtons[i].isClicked()) {
        autonButtons[autonToRun].buttonColor = vex::black;
        autonButtons[i].buttonColor = vex::green;
        autonToRun = i;
      }
    }
    wait(100, msec);
  }
}
